#!/bin/sh
php ./merge.php